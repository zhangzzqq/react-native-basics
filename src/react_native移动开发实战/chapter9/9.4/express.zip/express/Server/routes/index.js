var express = require('express');
var router = express.Router();

const db = require("../config/db");


/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });


/**
 * 查询列表页
 */
router.get('/', function (req, res, next) {
    db.query('select * from person', function (err, rows) {
        if (!err) {
            res.writeHead(200, {'Content-Type': 'text/html;charset=utf-8'});
            res.end(JSON.stringify(rows));
        }
    })
});

module.exports = router;





