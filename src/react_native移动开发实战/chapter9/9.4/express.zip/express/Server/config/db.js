const mysql = require('mysql');
const pool = mysql.createPool({
  host: 'localhost',
  port: '3306',
  user: 'root',
  password: '12345678',
  database: 'nodesql'
});

function query(sql, callback) {
  pool.getConnection(function (err, connection) {
    connection.query(sql, function (err, rows) {
      callback(err, rows);
      connection.release();
    });
  });
}
exports.query = query;
